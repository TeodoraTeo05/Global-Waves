package app.pages;

import app.user.User;

public final class LikedContentPage extends Page {
    /**
     * @param user
     */
    public LikedContentPage(final User user) {
        super(user);
    }

    /**
     * *method for printing the current page
     */
    public String currentPage() {
        return null;
    }
}
